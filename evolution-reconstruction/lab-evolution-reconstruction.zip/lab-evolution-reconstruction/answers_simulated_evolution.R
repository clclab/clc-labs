###
# Computer lab: Evolution and Phylogenetic reconstruction
# Script for simulating evolution (section 2)
# 
# Write your answers in this file.
###