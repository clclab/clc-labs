###
# Computer lab: Evolution and Phylogenetic reconstruction
# Script for phylogenetic tree reconstruction from biological data (sections 4 & 5)
# 
# Write your answers in this file.
###