###
# Computer lab: Evolution and Phylogenetic reconstruction
# Script for phylogenetic tree reconstruction from language data (section 6)
# 
# Write your answers in this file.
###