###
# Computer lab: Evolution and Phylogenetic reconstruction
# Script for phylogenetic tree reconstruction from simulated data (section 5)
# 
# Write your answers in this file.
###