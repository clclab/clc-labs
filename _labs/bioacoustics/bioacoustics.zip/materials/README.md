# Materials Computer Lab: Bioacoustics in Praat

Here you find all the materials you need for the computer lab *Bioacoustics in Praat*.
The PDF with the instructions and relevant background can be found on Canvas.

## Files

- `sine.wav`
- `bassoon.wav`
- `wermke-german-baby.wav`
- `wermke-chinese-baby.wav`
- `mampe-german-baby.wav`
- `mampe-french-baby.wav`
- `slit.wav`
- `mampe-2009.pdf`
- `marcus-1978.pdf`
- `wermke-2016.pdf`
