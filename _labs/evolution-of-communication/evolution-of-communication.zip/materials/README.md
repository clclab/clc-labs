# Materials Computer Lab: Evolution of communication

Here you find all the materials you need for the computer lab *Evolution of communication*. 
The PDF with the instructions and relevant background can be found on Canvas.

## Files

- ...