###
# Computer lab: Evolution of communication 
# Write your answers in this file.
###